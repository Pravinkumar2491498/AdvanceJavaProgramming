package problemStatement_5_1;
import java.util.Scanner;
public class myClass 
{
public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		String str = "JAVA is Simple";
		
		System.out.println("String to Uppercase :" + str.toUpperCase());
		
		System.out.println("String to Lowercase : " + str.toLowerCase());
		
		String[] words=str.split("\\s");	//1st words of letter
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
		
		String[] words1=str.split("\\s"); // Change order 
		for(String w:words1){  
			System.out.println(w); 
		}
		
		//String Builder reverse
		StringBuilder words2= new StringBuilder("JAVA is Simple");
		
		Object words21;
		System.out.println("String = " + words2.toString());
		StringBuilder reverseStr = words2.reverse();
		System.out.println("Reverse String = " + reverseStr.toString());
		
		//Total Length
		System.out.println("length of string " + str.length());
		

	}

}
