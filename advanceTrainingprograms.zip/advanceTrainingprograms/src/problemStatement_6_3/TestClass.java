package problemStatement_6_3;
import java.util.Vector;
public class TestClass {
	public static void main(String[] args) {
		Vector<Employee> v = main1();
		main11(v);
		}

	private static Vector<Employee> addInput() {
		// TODO Auto-generated method stub
		return null;
	}

	private static void display() {
		// TODO Auto-generated method stub
		
	}

	public static Vector<Employee> main1() {
		Employee e1=new Employee (123,"jhon", "us");
		Employee e2=new Employee (456,"mike", "london");
		Employee e3=new Employee (789,"kane", "paris");
		Vector<Employee> v=new Vector<Employee>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
		//System.out.println(v);
	}
public static void main11(Vector<Employee> v) {
		for(Employee e:v)
		{
			System.out.println(e.getEid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
	}
}