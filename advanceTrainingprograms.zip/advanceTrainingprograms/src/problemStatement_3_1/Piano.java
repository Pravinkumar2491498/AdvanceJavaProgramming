package problemStatement_3_1;

public class Piano extends Instruments
{
	@Override
	public void play() {
		System.out.println("Piano is playing - tan tan tan tan");

	}
}
