package problemStatement_3_1;

public abstract class Instruments 
{
	public abstract void play();

}
