package problemStatement_13;
public class Linked_List
{
    Node head; 
    class Node {
        int data;
        Node next;
        Node(int d)
        {
            data = d;
            next = null;
        }
    }
    
    void printNthFromLast(int n)
    {
        Node main_ptr = head;
        Node ref_ptr = head;
 
        int count = 0;
        if (head != null)
        {
            while (count < n)
            {
                if (ref_ptr == null)
                {
                    System.out.println(n + " is greater than the number of nodes ----> Value in the list -1");
                    return;
                }
                ref_ptr = ref_ptr.next;
                count++;
            }
 
            if(ref_ptr == null)
            {
              
              if(head != null)
                System.out.println("Node no. " + n + " from last is " + head.data);
            }
            else
            {
                   
              while (ref_ptr != null)
              {
                  main_ptr = main_ptr.next;
                  ref_ptr = ref_ptr.next;
              }
              System.out.println("Node no. last second is : " + main_ptr.data);
                                
                                  
            }
        }
    }
    public void push(int new_data)
    {
        
        Node new_node = new Node(new_data);
 
        
        new_node.next = head;
 
        
        head = new_node;
    }
    public static void main(String[] args)
    {
        Linked_List llist = new Linked_List();
        llist.push(11);
        llist.push(29);
        llist.push(38);
        llist.push(64);
        llist.push(58);
        llist.push(69);
        llist.push(97);
        llist.push(88);
        llist.push(79);
 
        llist.printNthFromLast(8);
        llist.printNthFromLast(10);
    }
}
