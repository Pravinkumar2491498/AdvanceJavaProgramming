package problemStatement_4_1;

public class BankAccount
{
	int accNo;
    String custName;
    String accType;
    double balance;
   
    
   
    public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	
	public double getBalance() {
       
        if( balance <1000)
        {
        try
        {   
            throw new NumberFormatException();
        }
        catch(NumberFormatException nw)
        {
            System.out.println("Balance is low = "+balance);
        }
        }
       
        return balance;
       
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }

    public BankAccount() {
       
        this.accNo = 123456789;
        this.custName = "Mukilan";
        this.accType = "Saving";
        this.balance = 500;
    }
   
   
    public BankAccount(int accNo, String custName, String accType, double balance) {
       
        this.accNo = accNo;
        this.custName = custName;
        this.accType = accType;
        this.balance = balance;
    }
    void deposit(double amt)
    {
        if(amt<0)
        {
            try
            {
                throw new NumberFormatException();
            }
            catch(NumberFormatException nf)
            {
                System.out.println("Negaive Amount cant be deposited");
            }
        }
        else
        {
            balance=getBalance()+amt;
            System.out.println("Current balance is = "+balance);
           
        }
    }
     public void withdraw(double amt){
         if(amt>1000)
            {
                try
                {
                    throw new NumberFormatException();
                }
                catch(NumberFormatException nf)
                {
                    System.out.println("WE CAN'T DEPOSIT AMOUNT - INSUFFICENT BALANCE ");
                }
            }
            else
            {
                balance=getBalance()-amt;
                System.out.println("Current balance is = "+balance);
               
            }
    }
     void display()
     {
    System.out.println("Balance is = "+getBalance());   
     }
   
    public static void main(String[] args) {
       
       
        BankAccount b=new BankAccount();
        b.deposit(2000);
        b.display();
        b.withdraw(500);
        b.display();
        b.withdraw(2000);
        b.getBalance();
        b.display();
    }
}
