package problemStatement_1_2;
import java.util.Scanner;
public class ShowEvenNumber1_1 
{
        public static void main(String[] args)
{
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter a number : ");
		int i;
		int num = scan.nextInt();
		
		for(i=0; i<=num; i++) 
		{
			
			if(i%2 == 0) {
				System.out.print(i + "\t");
			}
		}

	}

}



